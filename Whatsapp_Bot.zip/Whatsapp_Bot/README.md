<!--Please do not remove this part-->
![Star Badge](https://img.shields.io/static/v1?label=%F0%9F%8C%9F&message=If%20Useful&style=style=flat&color=BC4E99)
![Open Source Love](https://badges.frapsoft.com/os/v1/open-source.svg?v=103)

# Script Title

<!--An image is an illustration for your project, the tip here is using your sense of humour as much as you can :D 

You can copy paste my markdown photo insert as following:
<p align="center">
<img src="your-source-is-here" width=40% height=40%>
-->
![whatsappbot](https://user-images.githubusercontent.com/87910771/147886971-3b084c89-3370-43a6-9bf7-cf31716691be.png)


## 🛠️ Description
<!--Remove the below lines and add yours -->
A Simple Bot made using Python to Send WhatsApp Message.

## ⚙️ Languages or Frameworks Used
<!--Remove the below lines and add yours -->
Open Command Prompt and use the following command to install the required modules:

```sh 
pip install pywhatkit
```

## 🌟 How to run
<!--Remove the below lines and add yours -->
Just open a terminal in the folder where your script is located and run the following command:

```sh
python main.py
```

## 📺 Demo

![demo](https://user-images.githubusercontent.com/87910771/147886979-a12cd79a-8f49-4603-b568-4991dde28feb.jpg)



## 🤖 Author
<!--Remove the below lines and add yours -->
[AnishLohiya](https://github.com/AnishLohiya)
