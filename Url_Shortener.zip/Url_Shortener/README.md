<!--Please do not remove this part-->

![Star Badge](https://img.shields.io/static/v1?label=%F0%9F%8C%9F&message=If%20Useful&style=style=flat&color=BC4E99)

![Open Source Love](https://badges.frapsoft.com/os/v1/open-source.svg?v=103)

  

# URL Shortener

  

![enter image description here](https://www.clickslice.co.uk/wp-content/uploads/2022/07/1_Pdw7h5X6vQQNVopIzHBG6A.jpeg)

  

<!--An image is an illustration for your project, the tip here is using your sense of humour as much as you can :D

  

You can copy paste my markdown photo insert as following:

<p align="center">

<img src="your-source-is-here" width=40% height=40%>

-->

  

## 🛠️ Description

<!--Remove the below lines and add yours -->

A cli url shortener.

  

## ⚙️ Languages or Frameworks Used

<!--Remove the below lines and add yours -->

  
    pip install -r requirements.txt


## 🌟 How to run

<!--Remove the below lines and add yours -->

1. Replace the api_key in url_shortener.py to your bitly api key
2. Run the file !!

  

## 📺 Demo

![alt text](assets/ezgif-5-7fc3e9b8f1.gif)

  

## 🤖 Author

<!--Remove the below lines and add yours -->

[dongjin2008](https://github.com/dongjin2008)